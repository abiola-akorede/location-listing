<div class="mob-right-nav" data-wow-duration="0.5s">
    <div class="mob-right-nav-close"><i class="fa fa-times" aria-hidden="true"></i> </div>
    <h5>BeeTech</h5>
    <div class="v3-m-2" style="color: white;">
        <ul>
            <li style="color: white;"><a class='' href='#' style="color: white;"> Sale</a>
            </li>
            <li><a class='' href='#' style="color: white;"> Rent</a>
            </li>
            <li><a class='' href='#' style="color: white;">Project</a>
            </li>
            <li><a class='' href='#' style="color: white;">Materials</a>
            </li>
            <li><a class='' href='#' style="color: white;">Services</a>
            </li>
            <li><a class='' href='#' style="color: white;">Rent to Own</a>
            </li>
        </ul>
    </div>
    <ul class="mob-menu-icon">
        <li><a href="price.html">Add Business</a> </li>
        <li><a href="#!" data-toggle="modal" data-target="#register">Register</a> </li>
        <li><a href="#!" data-toggle="modal" data-target="#sign-in">Sign In</a> </li>
    </ul>
   
    
</div>